$(function () {
  var swiper = new Swiper('.swiper-container',{
    loop: true,
    autoplay:true
  });
})